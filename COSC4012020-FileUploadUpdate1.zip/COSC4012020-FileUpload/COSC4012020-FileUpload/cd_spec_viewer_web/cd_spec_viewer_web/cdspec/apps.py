from django.apps import AppConfig


class CdspecConfig(AppConfig):
    name = 'cd_spec_viewer_web.cdspec'

